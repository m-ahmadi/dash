define(() => {
	return () => {
		
		// Progressbar
		if ($(".progress .progress-bar")[0]) {
			$('.progress .progress-bar').progressbar();
		}
		// /Progressbar
	
	};
});
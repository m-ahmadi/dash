define(() => {
	return () => {
		
		// NProgress
		if (typeof NProgress !== 'undefined') {
			$(document).ready(function () {
				NProgress.start();
			});

			$(window).load(function () {
				NProgress.done();
			});
		}
		
	};
});
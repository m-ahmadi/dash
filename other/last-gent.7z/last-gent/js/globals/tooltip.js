define(() => {
	return () => {
	
	// Tooltip
	$(document).ready(function () {
		$('[data-toggle="tooltip"]').tooltip({
			container: 'body'
		});
	});
	// /Tooltip
	
	};
});
define(f() => {
	return () => {
		
		
	};
});